package com.example.projectlab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Accident extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accident);
    }
}