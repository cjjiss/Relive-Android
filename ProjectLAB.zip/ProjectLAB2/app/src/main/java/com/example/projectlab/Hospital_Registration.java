package com.example.projectlab;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class Hospital_Registration extends AppCompatActivity {
    EditText e1,e2,e3,e4,e5,e6;
    Button b1;
    TextView t1;

    FirebaseAuth auth;
    FirebaseFirestore firestore;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital_registration);

        e1 = (EditText) findViewById(R.id.ed_nameregh);
        e2 = (EditText) findViewById(R.id.ed_emailregh);
        e3 = (EditText) findViewById(R.id.ed_addregh);
        e4 = (EditText) findViewById(R.id.ed_phoneregh);
        e5 = (EditText) findViewById(R.id.ed_passregh);
        e6 = (EditText) findViewById(R.id.ed_cpassregh);

        b1 = (Button) findViewById(R.id.b5_regh);
        t1 = (TextView) findViewById(R.id.textView4);

        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Hospital_Registration.this,Hospital_login.class);
                startActivity(i);
            }
        });
    }
}